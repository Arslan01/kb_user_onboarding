Generated from http://www.favicomatic.com (transparent images)

Another option (with non-transparent images):
https://www.favicon-generator.org/
